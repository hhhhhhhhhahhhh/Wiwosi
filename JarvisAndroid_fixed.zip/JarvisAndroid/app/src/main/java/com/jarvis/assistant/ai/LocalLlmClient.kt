package com.jarvis.assistant.ai

import android.content.Context
import android.net.Uri
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Runs a language model directly on the phone via Google's LiteRT-LM runtime
 * (the actively-developed successor to the older MediaPipe LLM Inference API).
 * Reads standard ".litertlm" model bundles — the format most current models
 * on the LiteRT Community Hugging Face page are published in. No internet
 * needed after the model file is imported once, no API key, no quota.
 *
 * This is a plain chat fallback — it does NOT do tool/function calling here;
 * fixed commands are still handled by LocalCommandParser before this is ever
 * reached. (LiteRT-LM does support tool calling if we want to add that later.)
 *
 * The model file is NOT downloaded automatically, since the small/large Gemma
 * models on Hugging Face require accepting a license on your own account
 * first — embedding a personal access token in the app's public source would
 * leak it. Instead, the user downloads the file once in their own browser
 * (already logged in / license already accepted there), and picks it via the
 * system file picker, which this class then copies into the app's private
 * storage.
 */
class LocalLlmClient(private val context: Context) {

    private val modelFile: File
        get() = File(context.filesDir, MODEL_FILENAME)

    val isModelReady: Boolean
        get() = modelFile.exists() && modelFile.length() > 20_000_000L

    private var engine: Engine? = null
    private var conversation: Conversation? = null

    /** Copies a user-picked .litertlm model file into private storage. Returns true on success. */
    suspend fun importModel(sourceUri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val tempFile = File(context.filesDir, "$MODEL_FILENAME.part")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                tempFile.outputStream().use { output -> input.copyTo(output) }
            } ?: return@withContext false
            tempFile.renameTo(modelFile)
            resetEngine()
            isModelReady
        } catch (e: Exception) {
            false
        }
    }

    private fun resetEngine() {
        try { conversation?.close() } catch (e: Exception) { /* ignore */ }
        conversation = null
        try { engine?.close() } catch (e: Exception) { /* ignore */ }
        engine = null
    }

    private fun ensureLoaded(systemPrompt: String) {
        if (engine != null && conversation != null) return
        if (!isModelReady) return

        val newEngine = try {
            // GPU is much faster than CPU for this kind of model, when available.
            val gpuConfig = EngineConfig(
                modelPath = modelFile.absolutePath,
                backend = Backend.GPU(),
                cacheDir = context.cacheDir.absolutePath
            )
            Engine(gpuConfig).also { it.initialize() }
        } catch (e: Exception) {
            val cpuConfig = EngineConfig(
                modelPath = modelFile.absolutePath,
                backend = Backend.CPU(),
                cacheDir = context.cacheDir.absolutePath
            )
            Engine(cpuConfig).also { it.initialize() }
        }
        engine = newEngine

        conversation = newEngine.createConversation(
            ConversationConfig(
                systemInstruction = Contents.of(systemPrompt),
                samplerConfig = SamplerConfig(topK = 40, topP = 0.95, temperature = 0.8)
            )
        )
    }

    suspend fun reply(systemPrompt: String, userText: String): String = withContext(Dispatchers.IO) {
        if (!isModelReady) return@withContext "Yerel model henüz seçilmedi."
        try {
            ensureLoaded(systemPrompt)
        } catch (e: Exception) {
            resetEngine()
            return@withContext "Model yüklenemedi: ${e.message}"
        }
        val activeConversation = conversation ?: return@withContext "Model yüklenemedi."

        try {
            val response = activeConversation.sendMessage(userText)
            response.toString().ifBlank { "Bir cevap üretemedim, tekrar dener misin?" }
        } catch (e: Exception) {
            "Yerel model hatası: ${e.message}"
        }
    }

    companion object {
        private const val MODEL_FILENAME = "jarvis-local-model.litertlm"
    }
}
