package com.jarvis.assistant.actions

import android.content.Context
import android.content.Intent
import android.net.Uri

object BrowserActions {

    fun openUrl(context: Context, rawUrl: String): String {
        val url = if (!rawUrl.startsWith("http")) "https://$rawUrl" else rawUrl
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return "$url açıldı."
    }

    fun search(context: Context, query: String): String {
        val uri = Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")
        val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return "\"$query\" için Google'da arama yapıldı."
    }

    fun playYoutube(context: Context, query: String): String {
        return MediaActions.playYoutube(context, query)
    }
}
