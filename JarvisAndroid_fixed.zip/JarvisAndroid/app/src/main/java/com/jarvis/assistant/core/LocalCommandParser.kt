package com.jarvis.assistant.core

import android.content.Context
import com.jarvis.assistant.actions.AppLauncher
import com.jarvis.assistant.actions.BrowserActions
import com.jarvis.assistant.actions.CalendarActions
import com.jarvis.assistant.actions.MediaActions
import com.jarvis.assistant.actions.SystemInfoActions
import com.jarvis.assistant.actions.WhatsAppActions
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * JARVIS'in tamamen çevrimdışı (API'siz) komut anlayıcısı. Hiçbir yapay zekaya
 * bağlanmaz — sadece burada tanımlı örüntülere uyan cümleleri anlar. Eşleşme
 * yoksa null döner ve arayan taraf kullanıcıya örnek komutlar gösterir.
 */
object LocalCommandParser {

    private val openAppRegex = Regex("(.+?)\\s*(?:'?y[iı]|'?y[uü])?\\s*aç(?:sana|abilir misin)?\\.?$")
    private val weatherWords = listOf("hava durumu", "hava nasıl", "hava kaç derece")
    private val batteryWords = listOf("pil", "batarya", "şarj durumu")
    private val ramWords = listOf("ram", "hafıza durumu", "bellek durumu")
    private val diskWords = listOf("depolama", "disk durumu", "hafıza kart")
    private val timeWords = listOf("saat kaç", "saat ne")
    private val playRegex = Regex("(.+?)\\s+(çal|oynat)(?:sana)?\\.?$")
    private val whatsappRegex = Regex(
        "(.+?)\\s*'?(a|e|ya|ye)\\s+whatsapp\\S*\\s+(.+?)\\s+(yaz|gönder)(?:sana)?\\.?$"
    )
    private val reminderRegex = Regex(
        "(?:saat\\s+)?(\\d{1,2})[:.](\\d{2})('?te|'?da|'?de)?\\s+(.+?)\\s+hatırlat(?:sana)?\\.?$"
    )

    fun tryHandle(context: Context, text: String): String? {
        val normalized = text.trim().lowercase().replace("i̇", "i")

        whatsappRegex.find(normalized)?.let { match ->
            val name = match.groupValues[1].trim()
            val message = match.groupValues[3].trim()
            if (name.isNotBlank() && message.isNotBlank()) {
                return WhatsAppActions.sendMessage(context, name, message)
            }
        }

        reminderRegex.find(normalized)?.let { match ->
            val hour = match.groupValues[1].toIntOrNull()
            val minute = match.groupValues[2].toIntOrNull()
            val title = match.groupValues[4].trim()
            if (hour != null && minute != null && title.isNotBlank()) {
                val cal = Calendar.getInstance()
                cal.set(Calendar.HOUR_OF_DAY, hour)
                cal.set(Calendar.MINUTE, minute)
                cal.set(Calendar.SECOND, 0)
                if (cal.timeInMillis < System.currentTimeMillis()) {
                    cal.add(Calendar.DAY_OF_YEAR, 1)
                }
                val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault()).format(cal.time)
                return CalendarActions.addReminder(context, title, iso)
            }
        }

        // "Spotify'ı aç", "google aç" gibi
        openAppRegex.find(normalized)?.let { match ->
            val appName = match.groupValues[1].trim()
            if (appName.isNotBlank() && appName.split(" ").size <= 3) {
                return AppLauncher.open(context, appName)
            }
        }

        playRegex.find(normalized)?.let { match ->
            val query = match.groupValues[1].trim()
            if (query.isNotBlank()) {
                val provider = if (normalized.contains("spotify")) "spotify" else "youtube"
                return MediaActions.play(context, query.replace("spotify'da", "").replace("spotify", "").trim(), provider)
            }
        }

        if (weatherWords.any { normalized.contains(it) }) {
            val city = extractCity(normalized) ?: "Istanbul"
            return BrowserActions.search(context, "$city hava durumu")
        }

        if (batteryWords.any { normalized.contains(it) }) {
            return SystemInfoActions.query(context, "battery")
        }

        if (ramWords.any { normalized.contains(it) }) {
            return SystemInfoActions.query(context, "ram")
        }

        if (diskWords.any { normalized.contains(it) }) {
            return SystemInfoActions.query(context, "disk")
        }

        if (timeWords.any { normalized.contains(it) }) {
            return SystemInfoActions.query(context, "time")
        }

        return null
    }

    /** Very small heuristic: "İstanbul'da hava durumu" -> "İstanbul". Falls back to null. */
    private fun extractCity(normalized: String): String? {
        val match = Regex("([a-zçğıöşü]+)('?da|'?de)\\s+hava").find(normalized)
        return match?.groupValues?.get(1)?.replaceFirstChar { it.uppercase() }
    }
}
