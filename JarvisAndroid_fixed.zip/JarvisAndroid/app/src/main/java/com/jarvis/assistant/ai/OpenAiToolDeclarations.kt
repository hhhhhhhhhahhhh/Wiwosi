package com.jarvis.assistant.ai

import org.json.JSONArray
import org.json.JSONObject

/**
 * Same tool set as ToolDeclarations, but in the OpenAI-compatible "function" wrapper
 * format that xAI's Chat Completions endpoint expects (type: object, lowercase).
 */
object OpenAiToolDeclarations {

    private fun fn(name: String, description: String, properties: JSONObject, required: List<String>) =
        JSONObject()
            .put("type", "function")
            .put(
                "function",
                JSONObject()
                    .put("name", name)
                    .put("description", description)
                    .put(
                        "parameters",
                        JSONObject()
                            .put("type", "object")
                            .put("properties", properties)
                            .put("required", JSONArray(required))
                    )
            )

    private fun prop(desc: String) = JSONObject().put("type", "string").put("description", desc)

    val all: JSONArray = JSONArray().apply {
        put(fn("open_app", "Yüklü bir Android uygulamasını açar.",
            JSONObject().put("app_name", prop("Açılacak uygulamanın adı, örn. Spotify")),
            listOf("app_name")))

        put(fn("sys_info", "Pil, RAM, depolama veya saat bilgisini döner.",
            JSONObject().put("kind", prop("battery, ram, disk, time veya all")),
            listOf("kind")))

        put(fn("get_weather", "Bir şehrin güncel hava durumunu getirir.",
            JSONObject().put("location", prop("Şehir adı, örn. Istanbul")),
            listOf("location")))

        put(fn("browser_control", "URL açar, Google'da arama yapar veya YouTube'da bir şey oynatır.",
            JSONObject()
                .put("action", prop("open_url, search veya play_youtube"))
                .put("query", prop("Aranacak metin veya açılacak URL")),
            listOf("action", "query")))

        put(fn("play_media", "YouTube veya Spotify'da içerik arar ve açar.",
            JSONObject()
                .put("query", prop("Şarkı/video adı"))
                .put("provider", prop("youtube veya spotify")),
            listOf("query")))

        put(fn("send_whatsapp_message", "Bir kişiye WhatsApp üzerinden mesaj taslağı hazırlar.",
            JSONObject()
                .put("recipient", prop("Telefon numarası veya kayıtlı/rehberdeki kişi adı"))
                .put("message", prop("Gönderilecek mesaj metni")),
            listOf("recipient", "message")))

        put(fn("save_whatsapp_contact", "Sık kullanılan bir WhatsApp kişisini isim ve numara ile kaydeder.",
            JSONObject()
                .put("name", prop("Kişi adı"))
                .put("phone", prop("Telefon numarası, ülke koduyla")),
            listOf("name", "phone")))

        put(fn("save_memory", "Kullanıcı hakkında hatırlanması gereken bir bilgiyi kalıcı olarak kaydeder.",
            JSONObject()
                .put("key", prop("Kısa anahtar, örn. favori_renk"))
                .put("value", prop("Hatırlanacak bilgi")),
            listOf("key", "value")))

        put(fn("delete_memory", "Hafızadan bir kaydı siler.",
            JSONObject().put("key", prop("Silinecek anahtar")),
            listOf("key")))

        put(fn("get_calendar_events", "Takvim etkinliklerini listeler.",
            JSONObject().put("query", prop("today, tomorrow, week, month gibi bir zaman aralığı")),
            listOf("query")))

        put(fn("add_calendar_event", "Takvime yeni bir etkinlik ekler.",
            JSONObject()
                .put("title", prop("Etkinlik başlığı"))
                .put("start_iso", prop("Başlangıç zamanı ISO formatında, örn. 2026-07-06T14:00:00"))
                .put("end_iso", prop("Bitiş zamanı ISO formatında (opsiyonel)")),
            listOf("title", "start_iso")))

        put(fn("delete_calendar_event", "Başlığa göre bir takvim etkinliğini siler.",
            JSONObject().put("title", prop("Silinecek etkinliğin başlığı")),
            listOf("title")))

        put(fn("add_reminder", "Belirli bir zaman için hatırlatıcı ekler.",
            JSONObject()
                .put("title", prop("Hatırlatıcı başlığı"))
                .put("due_iso", prop("Hatırlatma zamanı, ISO formatında")),
            listOf("title", "due_iso")))

        put(fn("get_reminders", "Yaklaşan hatırlatıcıları listeler.",
            JSONObject().put("query", prop("today, upcoming gibi bir zaman aralığı")),
            listOf("query")))
    }
}
